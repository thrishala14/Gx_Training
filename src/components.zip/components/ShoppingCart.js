import "bootstrap/dist/css/bootstrap.css";
import React, {useReducer} from 'react'

const reducer=(state, action)=>{
    if(action.type == "add"){
        return {items: state.items.concat(action.value)}
    }
    if(action.type == "remove"){
        return {
        items: state.items.filter((item)=>item!=action.value)
      }}

}
const ShoppingCart = () => {
    const products = [
        {
            name: "item1",
            price: 200,
        },
        {
            name: "item2",
            price: 300,
        },
        {
            name: "item3",
            price: 400,
        },
        ];
        const[state, dispatch] = useReducer(reducer, {
            items: [{
                name: "Demo",
                price: 100
            }]
        })
  return (
    

    <div>
      <h2 className="text-light bg-dark text-center"> SHOPPING APPLICATION</h2>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Cart</th>
          </tr>
        </thead>
        <tbody>
          
      {products.map((item, index) => (
        <tr>
            <th scope="row">{index+1}</th>
            <td> {item.name}</td>
            <td> {item.price} </td>
            <td><button onClick={()=>dispatch({type:"add", value: item})}>ADD TO CART</button></td>
        </tr>
         
      ))}
      </tbody>
      </table>
      <h4>CART</h4>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Cart</th>
          </tr>
        </thead>
        <tbody>
      {state.items.map((item, index)=><tr>
            <th scope="row">{index+1}</th>
            <td> {item.name}</td>
            <td> {item.price} </td>
            <td><button onClick={()=>dispatch({type:"remove", value: item})}>REMOVE</button></td>
        </tr>)}
        </tbody>
        </table>
    </div>
    
)};

export default ShoppingCart;
