const Child =(props) =>{
return (
    <div>
        <p> This is message from Parent : {props.message}</p>
    </div>
)
}

export default Child